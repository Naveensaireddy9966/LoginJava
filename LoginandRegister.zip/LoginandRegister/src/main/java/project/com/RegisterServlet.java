package project.com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/login";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "root";
    String jdbcDriver ="com.mysql.jdbc.Driver";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String name = request.getParameter("username");
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	
    	PreparedStatement statement = null;
    	Connection conn = null;
    	try {
			Class.forName(jdbcDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	try {
    		
    		conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
    		String query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    		statement = conn.prepareStatement(query);
    		statement.setString(1, name);
    		statement.setString(2, email);
    		statement.setString(3, password);
    		statement.executeUpdate();
    		response.sendRedirect("Login.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
			
			
		}finally {
            try {
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
		}
    }
}

