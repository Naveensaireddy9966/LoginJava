package project.com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/login";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "root";
    String jdbcDriver ="com.mysql.jdbc.Driver";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    	String usernameOrEmail = request.getParameter("usernameOrEmail");
    	String password = request.getParameter("password");
    	
    	Connection conn = null;
        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
			Class.forName(jdbcDriver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
        
        try {
			conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
			String query = "SELECT * FROM users WHERE (username = ? OR email = ?) AND password = ?";
			statement = conn.prepareStatement(query);
			statement.setString(1, usernameOrEmail);
			statement.setString(2, usernameOrEmail);
			statement.setString(3, password);
			
			rs = statement.executeQuery();
			
			if(rs.next()) {
				response.sendRedirect("Welcome.jsp");
			}else {
				response.sendRedirect("Error.jsp");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		}finally {
            try {
                if (rs != null) rs.close();
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
