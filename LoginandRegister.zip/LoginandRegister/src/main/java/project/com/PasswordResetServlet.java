package project.com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/PasswordResetServlet")
public class PasswordResetServlet extends HttpServlet {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/login";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "root";
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        if (!newPassword.equals(confirmPassword)) {
            // Passwords do not match, handle the error (e.g., display an error message)
            response.sendRedirect("Error.jsp");
            return;
        }

        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet rs = null;

        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            String query = "SELECT * FROM users WHERE email = ?";
            statement = conn.prepareStatement(query);
            statement.setString(1, email);
            rs = statement.executeQuery();

            if (rs.next()) {
                // Email exists in the database, update the password
                String updateQuery = "UPDATE users SET password = ? WHERE email = ?";
                statement = conn.prepareStatement(updateQuery);
                statement.setString(1, newPassword);
                statement.setString(2, email);
                statement.executeUpdate();
                // Redirect to the login page
                response.sendRedirect("Login.jsp");
            } else {
                // Email does not exist in the database, handle the error
                response.sendRedirect("Error.jsp");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("Error.jsp");
        } finally {
            try {
                if (rs != null) rs.close();
                if (statement != null) statement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
